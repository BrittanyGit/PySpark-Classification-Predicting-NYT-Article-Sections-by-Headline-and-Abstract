

##### FUNCTIONS FOR DS 5110 FINAL PROJECT: GROUP 1 - NEW YORK TIMES (NYT) ARTICLE HEADLINE AND ABSTRACT ANALYSIS

## MEMBERS: AVNI MALIK (am7bf), BRITTANY NGUYEN (bhn4bf), CECILY WOLFE (cew4pf)

## SPRING 2022


# load modules

from pyspark.sql.functions import *

from pyspark.ml import Pipeline

from pyspark.ml.classification import LogisticRegression

from pyspark.ml.feature import VectorAssembler 

from pyspark.mllib.evaluation import MulticlassMetrics

from pyspark.ml.feature import StandardScaler
from pyspark.ml.feature import OneHotEncoder, StringIndexer, StringIndexerModel

from pyspark.ml.evaluation import MulticlassClassificationEvaluator

from pyspark.ml.classification import LogisticRegression
from pyspark.ml.feature import Tokenizer
from pyspark.ml.tuning import CrossValidator, ParamGridBuilder

from pyspark.ml.feature import RegexTokenizer, StopWordsRemover, CountVectorizer

from pyspark.ml.functions import vector_to_array
from pyspark.sql.window import Window

import numpy as np


from pyspark.sql import SparkSession



### FUNCTION TO COMPUTE THE TOP K ACCURACY OF CLASSIFICATIONS

def top_k_accuracy(df, category, k):
    
    '''
    Function that takes in a dataframe with probabilites an observation is of a given category and a predicted category (based on max prob) and returns the top k accuracy of the predictions
    
    inputs:
    df: input dataframe
    category (str): name of a column in df that contains the original category labels for the observations
    k: number of predictions to consider --> if the observation label is correctly predicted in the top k considered correct prediction
    
    output:
    accuracy: top k accuracy
    
    '''
    
    # add monotonically increasing id col to df
    df = df.withColumn('id', monotonically_increasing_id())
    
    # create new df with col prob_array by converting probability col with vectors of probabilities for each section to arrays of probs
    top_k_df = df.withColumn('prob_array', vector_to_array('probability'))
    
    # create array of distinct sections
    distinct_cats = list(df.groupby(category).count().sort('count', ascending = False).toPandas()[category])
    
    # create array of distinct sections
    sections = array([lit(i) for i in distinct_cats])
    
    # num of distinct sections
    num_distinct = len(distinct_cats)
    
    #  create array of distinct section ids
    sec_ids = array([lit(i) for i in range(num_distinct)])
    
    # add col with array of distinct sections for each elt and col with array of distinct section ids
    top_k_df = top_k_df.withColumn('all_sections', sections) \
                       .withColumn('sec_ids', sec_ids)

    
    # add col with zipped arrays (probability associated with section)
    top_k_df = top_k_df.withColumn('arrays_zipped', arrays_zip(top_k_df.prob_array, top_k_df.all_sections, top_k_df.sec_ids))
    
    # add col probs where create row for each elt (prob, section) in zipped array
    top_k_df = top_k_df.withColumn('probs_sections', explode(top_k_df.arrays_zipped)) \
                       .select('id', 'probs_sections')
    
    # create window to use a window function to rank probs for each id (article)
    window = Window.partitionBy(top_k_df['id']).orderBy(top_k_df['probs_sections'].desc())
    
    # take top k probability values (and sections) for prediction
    top_k_probs = top_k_df.select('*', rank().over(window).alias('rank')) \
                          .filter(col('rank') <= k)
    
    # split probs_section col with zipped array into probs, section_preds
    top_k_probs = top_k_probs.withColumn('probs', col('probs_sections.prob_array')) \
                             .withColumn('section_preds', col('probs_sections.all_sections')) \
                             .withColumn('section_index_preds', col('probs_sections.sec_ids'))
    
    # left join with original df to see the true section and index for each article vs. top k predicted sections for article
    joined = top_k_probs.join(df.select('id', category, category + 'Index'), ['id'], how = "left")
    
    # group by id and section index then collect predicted section idices into a col of arrays of predicted indices
    section_index_preds_list = joined.groupby('id', category + 'Index') \
                                     .agg(collect_list("section_index_preds").alias("index_preds_list"))
    
    # convert to rdd with sectionIndex, index_preds_list
    section_index_preds_rdd = section_index_preds_list.select(category + 'Index', 'index_preds_list').rdd
    
    # calculate accuracy -> 1 if sectionIndex in index_preds_list, 0 otherwise -> sum correct predictions and count
    accuracy = section_index_preds_rdd.map(lambda row: (1 if row[0] in row[1] else 0)).sum() / section_index_preds_rdd.count()
    
    return accuracy



### FUNCTION TO BALANCE DATA (ALL CATEGORIES WITH NUMBER OF OBSERVATIONS AROUND THE MEAN OF NUMBER OF OBSERVATIONS IN ALL CATEGORIES)

def balance_categories(df, category_col):
    """
    inputs:
    df              spark dataframe
    category_col    column in df with categories
    
    output:
    new_df          balanced dataframe (with the number of observations in each category in category_col under/oversampled to be ~ the mean number of articles in each section)
    
    """
    # spark context
    spark = SparkSession.builder \
        .appName("test_11") \
        .config("spark.executor.memory", '20g') \
        .getOrCreate()
    
    # create an empty RDD
    empty_RDD = spark.sparkContext.emptyRDD()
    
    # create an empty dataframe with the same schema as the dataframe used as input
    new_df = spark.createDataFrame(data = empty_RDD, schema = df.schema)
    
    # count by label
    cat_counts = df.groupby(category_col).count().sort("count", ascending = False)
    
    # overall mean count per label / category
    mean_cat_count = int(np.round(cat_counts.agg({"count": 'mean'}).collect()[0][0]))
    
    # labels with counts > mean
    over_cats = list(cat_counts.filter(cat_counts["count"] > mean_cat_count).select(category_col).toPandas()[category_col])
    
    # labels with counts <= mean
    under_cats = list(cat_counts.filter(cat_counts["count"] <= mean_cat_count).select(category_col).toPandas()[category_col])
    
    cats = under_cats + over_cats
    
    # for each category
    for i in cats:
        
        # filter the dataframe for observations in that category
        cat_df = df.filter(df[category_col] == i)
        
        # fraction of mean num of articles across categories divided by the number of articles in that category
        frac = mean_cat_count / cat_df.count()
        
        # randomly under/oversample with replacement so that the number of observations in each section ~ mean num of articles over cats
        new_count_df = cat_df.sample(withReplacement = True, fraction = frac, seed = 42)
        
        # add new rows to originally empty df
        new_df = new_df.union(new_count_df)
        
    
    return new_df


